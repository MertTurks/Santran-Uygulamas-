﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Satranc
{
    public class Fil : Tas
    {
        public int ilkKonum { get; set; }
        public override void HareketEt(Form1 frm)
        {

            List<Yon> gidilebilecekYonler = GidilebilecekYonler();    //Debug sebebi: Fil oynatırken çok fazla hata alınması
            Label filEskiKonum = ButonBul(frm);
            Random rnd = new Random();

            bool filHamleYaptiMi = false;
            Label geciciFil;
            int geciciFilKonum = 0;
            do
            {
                if (gidilebilecekYonler.Count > 0)
                {


                    int gidilecekYonIndex = rnd.Next(0, gidilebilecekYonler.Count);
                    int gidilecekYonIndex2 = rnd.Next(0, gidilebilecekYonler.Count);
                    Yon gidilecekYon = gidilebilecekYonler[gidilecekYonIndex];
                    Yon gidilecekYon2 = gidilebilecekYonler[gidilecekYonIndex2];

                    var gidilebilecekButonlar = BuYondeGidilebilecekButonlar(gidilecekYon, frm);
                    if (gidilebilecekButonlar.Count > 0)
                    {
                        
                        int deneme = gidilebilecekButonlar.Count;
                        int random = rnd.Next(0, deneme);
                        Konum = gidilebilecekButonlar[random];

                        if (gidilecekYon == Yon.Sag || gidilecekYon == Yon.Sol)
                        {
                            int rastgeleYonIndex = rnd.Next(0, 2);
                            if (gidilecekYon == Yon.Sag)
                            {
                                if (gidilecekYon2==Yon.Yukari) // SagYukarı Yönü
                                {
                                    //int geciciKonumFil = Konum;
                                    //geciciKonumFil -= (random + 1) * 8;

                                    int x = Konum - ilkKonum;
                                    geciciFilKonum -= x * 8;

                                    //if (!SagSinirdaMiFil(Konum) && !UstSinirdaMiFil(Konum)) //Tamamlandı
                                    if (!AltSinirdaMiFil(geciciFilKonum) && !SolSinirdaMiFil(geciciFilKonum) && !SagSinirdaMiFil(geciciFilKonum) && !UstSinirdaMiFil(geciciFilKonum))
                                    {
                                        if (geciciFilKonum < 64 & geciciFilKonum > 0)
                                        {
                                            geciciFil = frm.Controls.Find(("lbl" + (geciciFilKonum).ToString()), true).FirstOrDefault() as Label;
                                            if (geciciFil.Image == null)
                                            {
                                                filEskiKonum.Image = null;
                                                Label filYeniKonum = ButonBul(frm);
                                                ResimGuncelle(this, filYeniKonum);
                                                filHamleYaptiMi = true;
                                            }
                                        }
                                    }

                                }

                                else if(gidilecekYon2 == Yon.Asagi)//sagaltsıkıntılı
                                {
                                    //int geciciKonumFil = Konum;
                                    //geciciKonumFil += (random + 1) * 8;

                                    int x = Konum - ilkKonum;
                                    geciciFilKonum += x * 8;

                                    //if (!AltSinirdaMiFil(Konum) && !SagSinirdaMiFil(Konum))
                                    if (!UstSinirdaMiFil(geciciFilKonum) && !SolSinirdaMiFil(geciciFilKonum) && !SagSinirdaMiFil(geciciFilKonum) && !AltSinirdaMiFil(geciciFilKonum))
                                    //if (Konum < 64 & Konum > 0)  //hatalı kontrol
                                    {
                                        if (geciciFilKonum < 64 & geciciFilKonum > 0)
                                        {
                                            geciciFil = frm.Controls.Find(("lbl" + (geciciFilKonum).ToString()), true).FirstOrDefault() as Label;
                                            if (geciciFil.Image == null)
                                            {
                                                filEskiKonum.Image = null;
                                                Label kaleYeniKonum = ButonBul(frm);
                                                ResimGuncelle(this, kaleYeniKonum);
                                                filHamleYaptiMi = true;
                                            }
                                        }
                                    }
                                }
                            }
                            else if (gidilecekYon == Yon.Sol)
                            {
                                if (gidilecekYon2 == Yon.Yukari) //solyukarı//hata
                                {
                                    //int geciciKonumFil = Konum;
                                    //geciciKonumFil -= (random + 1) * 8;

                                    int x = ilkKonum - Konum;
                                    geciciFilKonum -= x * 8;
                                    
                                    if (!UstSinirdaMiFil(geciciFilKonum) && !SolSinirdaMiFil(geciciFilKonum) && !SagSinirdaMiFil(geciciFilKonum) && !AltSinirdaMiFil(geciciFilKonum))
                                    {
                                        if (geciciFilKonum < 64 & geciciFilKonum > 0)
                                        {
                                            geciciFil = frm.Controls.Find(("lbl" + (geciciFilKonum).ToString()), true).FirstOrDefault() as Label;
                                            if (geciciFil.Image == null)
                                            {
                                                filEskiKonum.Image = null;
                                                Label filYeniKonum = ButonBul(frm);
                                                ResimGuncelle(this, filYeniKonum);
                                                filHamleYaptiMi = true;
                                            }
                                        }
                                    }
                                }
                                else if(gidilecekYon2 == Yon.Asagi) //solasagı
                                {
                                    //int geciciKonumFil = Konum;
                                    //geciciKonumFil += (random + 1) * 8;  //dogru

                                    int x = ilkKonum - Konum;
                                    geciciFilKonum += x * 8;

                                    if (!AltSinirdaMiFil(geciciFilKonum) && !SolSinirdaMiFil(geciciFilKonum))
                                    // if (!AltSinirdaMiFil(geciciFilKonum) && !SolSinirdaMiFil(geciciFilKonum) && !SagSinirdaMiFil(geciciFilKonum) && !UstSinirdaMiFil(geciciFilKonum))
                                    //if (Konum < 64 & Konum > 0)
                                    {
                                        if (geciciFilKonum < 64 & geciciFilKonum > 0)
                                        {
                                            geciciFil = frm.Controls.Find(("lbl" + (geciciFilKonum).ToString()), true).FirstOrDefault() as Label;
                                            if (geciciFil.Image == null)
                                            {
                                                filEskiKonum.Image = null;
                                                Label filYeniKonum = ButonBul(frm);
                                                ResimGuncelle(this, filYeniKonum);
                                                filHamleYaptiMi = true;
                                            }
                                        }
                                    }
                                }

                            }

                        }
                        else if (gidilecekYon == Yon.Yukari || gidilecekYon == Yon.Asagi)
                        {
                            int rastgeleYonIndex = rnd.Next(0, 2);
                            if (gidilecekYon == Yon.Yukari)
                            {
                                if (gidilecekYon2==Yon.Sol) //sol için yukarı
                                {
                                    //int geciciKonumFil = Konum;
                                    //geciciKonumFil -= (random + 1) * 1; //1 adım sola gittiği için farklı bir hesap-+

                                    int x = (ilkKonum - Konum) / 8;
                                    geciciFilKonum -= x;
                                   if (!UstSinirdaMiFil(geciciFilKonum) && !SolSinirdaMiFil(geciciFilKonum))
                                    //if (!UstSinirdaMiFil(geciciFilKonum) && !SolSinirdaMiFil(geciciFilKonum) && !SagSinirdaMiFil(geciciFilKonum) && !AltSinirdaMiFil(geciciFilKonum) && geciciFilKonum < 64 && geciciFilKonum > 0)
                                    //if (Konum < 64 & Konum > 0)
                                    {
                                        if (geciciFilKonum < 64 & geciciFilKonum > 0)
                                        {
                                            geciciFil = frm.Controls.Find(("lbl" + (geciciFilKonum).ToString()), true).FirstOrDefault() as Label;
                                            if (geciciFil.Image == null)
                                            {
                                                filEskiKonum.Image = null;
                                                Label filYeniKonum = ButonBul(frm);
                                                ResimGuncelle(this, filYeniKonum);
                                                filHamleYaptiMi = true;
                                            }
                                        }
                                    }
                                }
                                else if(gidilecekYon2 == Yon.Sag) //DOGRU yukarı sag
                                {
                                    //int geciciKonumFil = Konum;
                                    //geciciKonumFil += (random + 1) * 1;
                                    int x = (ilkKonum - Konum) / 8;
                                    geciciFilKonum += x;
                                    if (!UstSinirdaMiFil(geciciFilKonum) && !SagSinirdaMiFil(geciciFilKonum))
                                    // if (!UstSinirdaMiFil(geciciFilKonum) && !SagSinirdaMiFil(geciciFilKonum) && !SolSinirdaMiFil(geciciFilKonum) && !AltSinirdaMiFil(geciciFilKonum))
                                    //if (Konum < 64 & Konum > 0)
                                    {
                                        if (geciciFilKonum < 64 & geciciFilKonum > 0)
                                        {
                                            geciciFil = frm.Controls.Find(("lbl" + (geciciFilKonum).ToString()), true).FirstOrDefault() as Label;
                                            if (geciciFil.Image == null)
                                            {
                                                filEskiKonum.Image = null;
                                                Label filYeniKonum = ButonBul(frm);
                                                ResimGuncelle(this, filYeniKonum);
                                                filHamleYaptiMi = true;
                                            }
                                        }
                                    }
                                }
                            }
                            if (gidilecekYon == Yon.Asagi)
                            {
                                if (gidilecekYon2 == Yon.Sol) //asagı sol
                                {
                                    //int geciciKonumFil = Konum;
                                    //geciciKonumFil -= (random + 1) * 1;     

                                    int x = (Konum - ilkKonum) / 8;
                                    geciciFilKonum -= x;
                                   if (!AltSinirdaMiFil(geciciFilKonum) && !SolSinirdaMiFil(geciciFilKonum))
                                    // if (!UstSinirdaMiFil(geciciFilKonum) && !SagSinirdaMiFil(geciciFilKonum) && !SolSinirdaMiFil(geciciFilKonum) && !AltSinirdaMiFil(geciciFilKonum))
                                    {
                                        if (geciciFilKonum < 64 & geciciFilKonum > 0)
                                        {
                                            geciciFil = frm.Controls.Find(("lbl" + (geciciFilKonum).ToString()), true).FirstOrDefault() as Label;
                                            if (geciciFil.Image == null)
                                            {
                                                filEskiKonum.Image = null;
                                                Label filYeniKonum = ButonBul(frm);
                                                ResimGuncelle(this, filYeniKonum);
                                                filHamleYaptiMi = true;
                                            }
                                        }
                                    }
                                }
                                else if (gidilecekYon2 == Yon.Sag)
                                {
                                    //int geciciKonumFil = Konum;  asagısag
                                    //geciciKonumFil += (random + 1) * 1;

                                    int x = (Konum - ilkKonum) / 8;
                                    geciciFilKonum += x;
                                    if (!AltSinirdaMiFil(geciciFilKonum) && !SagSinirdaMiFil(geciciFilKonum))
                                    // if (!UstSinirdaMiFil(geciciFilKonum) && !SolSinirdaMiFil(geciciFilKonum) && !SagSinirdaMiFil(geciciFilKonum) && !AltSinirdaMiFil(geciciFilKonum) && geciciFilKonum < 64 && geciciFilKonum > 0)
                                    //if (Konum < 64 & Konum > 0)
                                    {
                                        if (geciciFilKonum < 64 & geciciFilKonum > 0)
                                        {
                                            geciciFil = frm.Controls.Find(("lbl" + (geciciFilKonum).ToString()), true).FirstOrDefault() as Label;
                                            if (geciciFil.Image == null)
                                            {
                                                filEskiKonum.Image = null;
                                                Label filYeniKonum = ButonBul(frm);
                                                ResimGuncelle(this, filYeniKonum);
                                                filHamleYaptiMi = true;
                                            }
                                        }
                                    }
                                }
                            }

                        }

                        else
                        {
                            filHamleYaptiMi = false;
                        }
                    }
                }
                else
                {
                    break;
                }

            } while (!filHamleYaptiMi);
        }
    }
}
