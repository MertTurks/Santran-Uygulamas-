﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Satranc
{
    class OyunTahtasi
    {
        List<Tas> oyunTaslari = new List<Tas>();

        private Form1 form;

        public OyunTahtasi(Form1 form)
        {
            this.form = form;
            int sayac = 0, yatay = 0, dikey = 0;
            Color renk = Color.Black;
            System.Windows.Forms.Panel pnlTahta;

            for (int i = 0; i < 64; i++)
            {
                Label lbl = new Label();
                lbl.BackColor = renk;
                lbl.Location = new System.Drawing.Point(yatay, dikey);
                lbl.Name = "lbl" + (i + 1);
                lbl.Size = new System.Drawing.Size(50, 50);
                lbl.FlatStyle = FlatStyle.Flat;
                form.pnlTahta.Controls.Add(lbl);
                lbl.Click += Btn_Click;

                sayac++;

                yatay += 50;
                if (yatay == form.pnlTahta.Size.Height)
                {
                    sayac++;

                    yatay = 0;
                    dikey += 50;
                }

                if (sayac % 2 == 0)
                {
                    renk = Color.Black;
                }
                else
                {
                    renk = Color.White;
                }
            }
        }

        private void Btn_Click(object sender, EventArgs e)
        {
            MessageBox.Show(((Label)sender).Name + " e tıkladın.");

        }

        public int BosYerBul(Form form)
        {
            int konum;
            bool kontrol = false;
            Random rnd = new Random();

            do
            {
                konum = rnd.Next(1, 65);
                Label OlusacakTas = form.Controls.Find(("lbl" + konum), true).FirstOrDefault() as Label;

                if (OlusacakTas.Image == null)
                    kontrol = false;
                else
                    kontrol = true;
            }
            while (kontrol);
            return konum;
        }

        public void TasOlustur(Form1 form)
        {
            int konum = BosYerBul(form);

            Label OlusacakTas = form.Controls.Find(("lbl" + konum.ToString()), true).FirstOrDefault() as Label;

            int newSize = 50;
            OlusacakTas.Font = new Font(OlusacakTas.Font.FontFamily, newSize);
            if (form.cmbTas.SelectedIndex == 0) //kale seçilirse
            {
                OlusacakTas.Image = global::Satranc.Properties.Resources.kale;
                Kale kale = new Kale();
                kale.Konum = konum;
                oyunTaslari.Add(kale);
            }
            else if (form.cmbTas.SelectedIndex == 1) //fil seçilirse
            {
                OlusacakTas.Image = global::Satranc.Properties.Resources.fil;
                Fil fil = new Fil();
                fil.Konum = konum;
                fil.ilkKonum = konum;
                oyunTaslari.Add(fil);

            }
            else if (form.cmbTas.SelectedIndex == 2) //at seçilirse
            {
                OlusacakTas.Image = global::Satranc.Properties.Resources.at;
                At at = new At();
                at.Konum = konum;
                oyunTaslari.Add(at);
            }
        }

        public void TaslariHareketEttir()
        {
            foreach (var item in oyunTaslari)
            {
                item.HareketEt(form);
            }
        }
    }
}
