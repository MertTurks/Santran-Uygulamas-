﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Satranc
{
    public class At : Tas
    {
        public bool DoluMu(Form1 frm)
        {
            Label atYeniKonum = ButonBul(frm);
            return true;
        }

        public override void HareketEt(Form1 form)
        {
            Label atEskiKonum = ButonBul(form);

            List<Yon> gidilebilecekYonler = GidilebilecekYonler();

            Random rnd = new Random();
            bool atHamleYapabildiMi = false;
            int gidilecekYonIndex;
            Yon gidilecekYon;
            int geciciAtKonum = 0;
            Label geciciAt;

            do
            {
                if (gidilebilecekYonler.Count > 0)
                {
                    gidilecekYonIndex = rnd.Next(0, gidilebilecekYonler.Count);
                    gidilecekYon = gidilebilecekYonler[gidilecekYonIndex];
                    var gidilebilecekButonlar = BuYondeGidilebilecekButonlar(gidilecekYon, form);


                    if (gidilebilecekButonlar.Count > 1)
                    {

                        if (gidilecekYon == Yon.Sag || gidilecekYon == Yon.Sol)
                        {

                            if (gidilecekYon == Yon.Sag)
                            {
                                geciciAtKonum = Konum + 2;
                            }

                            if (gidilecekYon == Yon.Sol)
                            {
                                geciciAtKonum = Konum - 2;
                            }

                            int rastgeleYonIndex = rnd.Next(0, 2);


                            if (rastgeleYonIndex == 0)
                            {
                                if (!UstSinirdaMi())
                                {
                                    geciciAtKonum = geciciAtKonum - 8;
                                    geciciAt = form.Controls.Find(("lbl" + (geciciAtKonum).ToString()), true).FirstOrDefault() as Label;

                                    if (geciciAt.Image == null)
                                    {
                                        atEskiKonum.Image = null;
                                        Konum = geciciAtKonum;
                                        Label atYeniKonum = ButonBul(form);
                                        ResimGuncelle(this, atYeniKonum);
                                        atHamleYapabildiMi = true;
                                    }
                                }
                            }
                            else
                            {
                                if (!AltSinirdaMi())
                                {
                                    geciciAtKonum = geciciAtKonum + 8;
                                    geciciAt = form.Controls.Find(("lbl" + (geciciAtKonum).ToString()), true).FirstOrDefault() as Label;

                                    if (geciciAt.Image == null)
                                    {
                                        atEskiKonum.Image = null;
                                        Konum = geciciAtKonum;
                                        Label atYeniKonum = ButonBul(form);
                                        ResimGuncelle(this, atYeniKonum);
                                        atHamleYapabildiMi = true;
                                    }
                                }
                            }

                        }
                        else
                        {
                            if (gidilecekYon == Yon.Yukari || gidilecekYon == Yon.Asagi)
                            {

                                if (gidilecekYon == Yon.Yukari)
                                {
                                    geciciAtKonum = Konum - 16;
                                }

                                if (gidilecekYon == Yon.Asagi)
                                {
                                    geciciAtKonum = Konum + 16;
                                }


                                int rastgeleYonIndex = rnd.Next(0, 2);


                                if (rastgeleYonIndex == 0)
                                {

                                    if (!SagSinirdaMi())
                                    {
                                        geciciAtKonum = geciciAtKonum + 1;
                                        geciciAt = form.Controls.Find(("lbl" + (geciciAtKonum).ToString()), true).FirstOrDefault() as Label;

                                        if (geciciAt.Image == null)
                                        {
                                            atEskiKonum.Image = null;
                                            Konum = geciciAtKonum;
                                            Label atYeniKonum = ButonBul(form);
                                            ResimGuncelle(this, atYeniKonum);
                                            atHamleYapabildiMi = true;
                                        }
                                    }
                                }
                                else
                                {

                                    if (!AltSinirdaMi())
                                    {
                                        geciciAtKonum = geciciAtKonum - 1;
                                        geciciAt = form.Controls.Find(("lbl" + (geciciAtKonum).ToString()), true).FirstOrDefault() as Label;

                                        if (geciciAt.Image == null)
                                        {
                                            atEskiKonum.Image = null;
                                            Konum = geciciAtKonum;
                                            Label atYeniKonum = ButonBul(form);
                                            ResimGuncelle(this, atYeniKonum);
                                            atHamleYapabildiMi = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {

                        gidilebilecekYonler.Remove(gidilecekYon);
                        atHamleYapabildiMi = false;
                    }
                }
                else
                {
                    break;
                }

            } while (!atHamleYapabildiMi);

        }
    }
}
